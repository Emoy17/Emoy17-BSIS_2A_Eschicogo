 <a href="logout.php"><font color="blue">LOG OUT</font></a><br>
  <a href="index.php"><font color="blue">BACK TO HOME</font></a>
  <!DOCTYPE html>
  <html>
  <head>
  	<meta charset="utf-8">
  	<title>YOUR TICKET</title>
  </head>
  <body>
  <center><font color="red"><h1>Congratulations on your successful payment and seat reservation.</h1></font>
  	<a href="ticke_show.php" target="_blank"><font color="blue"><h3>GET YOUR TICKET</h3></center></font></a>
  </body>
  </html>